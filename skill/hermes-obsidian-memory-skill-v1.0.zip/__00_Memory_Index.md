# 🧠 Hermes Memory Index

> **Purpose:** Navigation layer for all session logs and nightly summaries.
> **Last Updated:** 2026-06-30
> **Timezone:** America/Chicago

---

## Legend

| Icon | Meaning |
|------|---------|
| 📝 Session | Raw verbatim user prompts + Hermes responses |
| 🌙 Summary | Nightly compressed summary of Hermes responses/actions only |
| ✅ Summarized | Nightly cron completed successfully |
| ❌ Not yet | Still within the same day |

---

## Session & Summary Log

| Date | Session File | Summary File | Status | Key Topics | Related Tasks |
|------|--------------|--------------|--------|------------|---------------|
| 2026-06-30 | [📝 Session](./Sessions/2026-06-30_Session.md) | [🌙 Summary](./Summaries/2026-06-30_Summary.md) | ❌ Not yet | — | — |

---

## Quick Stats

- **Total sessions:** 1
- **Total summaries:** 0
- **Earliest session:** 2026-06-30
- **Latest session:** 2026-06-30
