# Hermes Obsidian — System README

> **Last updated:** 2026-06-30
> **Purpose:** Quick orientation for any Hermes session that needs to locate files, understand the memory system, or recover context from past sessions.

---

## 🔒 Hard Access Boundary

**Only this folder (`/vault/Hermes_Agent_Folder/`) is ever read, written, or searched.**  
No other folder or file in the vault is accessible. This is a permanent rule.

---

## 📁 Folder Map

```text
/vault/Hermes_Agent_Folder/
├── Todo_Tasks/                        ← Task tracking
│   ├── __00_Todo_Task_Index.md         ← Master task index (source of truth)
│   └── T##_*.md                        ← Per-task detail files
└── Hermes_Memory/                     ← Memory system ← YOU ARE HERE
    ├── Hermes_Obsidian_Readme.md       ← This file — system orientation
    ├── __00_Memory_Index.md            ← Navigation layer (sessions + summaries)
    ├── Sessions/                       ← Verbatim daily session logs (append-only)
    │   └── YYYY-MM-DD_Session.md
    ├── Summaries/                      ← Nightly compressed summaries
    │   └── YYYY-MM-DD_Summary.md
    ├── Templates/                      ← File templates
    ├── Scripts/                        ← Logging & summarization scripts
    ├── Hooks/                          ← Hermes plugin hook implementations
    └── Memory_Implementation_Plan.md   ← The original approved technical plan
```

---

## 🚀 Startup / Context Recovery Protocol

When a new Hermes session starts and needs continuity from past work:

1. **Read this file** — understand the folder structure.
2. **Read Hermes_Memory/__00_Memory_Index.md** — see what exists and when.
3. **Read the latest 3-5 summaries** from Hermes_Memory/Summaries/ — key decisions, learnings, pending tasks.
4. **Read Todo_Tasks/__00_Todo_Task_Index.md** — current task status.
5. **Optionally read today's session** from Sessions/ for the most current detail.
6. **Provide a context summary** to the user showing what was recovered.

---

## 📋 Task/Todo System

- **`Todo_Tasks/__00_Todo_Task_Index.md`** is the sole source of truth for all tasks.
- Each task has its own file under `Todo_Tasks/` for detailed notes and research.
- Calendar invites are only created for specific date/time commitments — otherwise tracked in the index.
- Status values: 🟢 Active, 🔵 In Progress, 🟡 Stalled, 🟣 Wishlist, ✅ Completed.

---

## 🧠 Memory System

- **Sessions/`YYYY-MM-DD_Session.md`** — Every turn is recorded:
  - User prompts stored verbatim
  - Hermes responses stored verbatim or in detail
  - Files are **append-only** — never edited after recording
- **Summaries/`YYYY-MM-DD_Summary.md`** — Generated nightly by Hermes cron job:
  - Compresses Hermes responses/actions only
  - Extracts: key learnings, decisions, solutions, errors, pending tasks
  - Cross-checks pending tasks against `Todo_Tasks/__00_Todo_Task_Index.md`
- **`__00_Memory_Index.md`** — Navigation layer linking sessions and summaries.

---

## ⚙️ Automation

| Automation | Schedule | Purpose |
|------------|----------|---------|
| Nightly Summary Cron | Daily at 12:15 AM CT | Compress day's Hermes responses, cross-check tasks, update index |
| Hermes Plugin Hooks | Per-turn (real-time) | Auto-capture user prompts + Hermes responses to session files |

---

## 🤝 Sharing

This memory system is packaged as a Hermes skill for community use. See the skill definition for:
- Installation instructions
- Plugin hook code
- Cron job setup
- Template files

---

*If you are a new Hermes session reading this: follow the Startup Protocol above before continuing.*