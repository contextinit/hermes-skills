# TDD Test: Hermes_Obsidian_Readme.md

## Test 4.1 — File exists
- **Action:** Check `Hermes_Memory/Hermes_Obsidian_Readme.md` exists.
- **Expected:** File exists, non-empty.
- **Pass if:** File size > 500 bytes.

## Test 4.2 — All referenced paths exist
- **Action:** Extract all paths mentioned in the file (Todo_Tasks/, Hermes_Memory/ etc).
- **Expected:** Every path referenced exists in the filesystem.
- **Pass if:** No broken path references.

## Test 4.3 — Startup protocol present
- **Action:** Read file for "Startup / Context Recovery Protocol" or "Startup Protocol".
- **Expected:** Section exists with numbered steps.
- **Pass if:** Section found.

## Test 4.4 — No stale self-reference
- **Action:** Confirm the folder map shows README inside Hermes_Memory/ not at root.
- **Expected:** The map has "├── Hermes_Obsidian_Readme.md" indented under "Hermes_Memory/".
- **Pass if:** Correct indentation.

## Test 4.5 — Hard boundary rule stated
- **Action:** Check for "Hard Access Boundary" or "🟢 Active".
- **Expected:** File states that only /vault/Hermes_Agent_Folder/ is accessible.
- **Pass if:** Boundary statement found.
