# TDD Test: Memory_Implementation_Plan.md

## Test 7.1 — File exists
- **Action:** Check file exists.
- **Expected:** File exists, non-empty.
- **Pass if:** File size > 2000 bytes.

## Test 7.2 — No stale references to old folder names
- **Action:** Grep for "Hermes_Memmory" and "Hermes_Obisidian".
- **Expected:** Zero matches.
- **Pass if:** grep returns nothing.

## Test 7.3 — Section 12 answers are populated
- **Action:** Read questions section.
- **Expected:** Answers have been filled in (lines after each question are non-empty).
- **Pass if:** User responses are present.
