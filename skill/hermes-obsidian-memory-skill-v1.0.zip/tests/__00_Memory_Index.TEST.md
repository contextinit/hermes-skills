# TDD Test: __00_Memory_Index.md

## Test 3.1 — File exists
- **Action:** Check `Hermes_Memory/__00_Memory_Index.md` exists.
- **Expected:** File exists and is non-empty.
- **Pass if:** File size > 100 bytes.

## Test 3.2 — Required sections present
- **Action:** Read the file and check for sections.
- **Expected:** Contains "Hermes Memory Index", "Session & Summary Log" table, "Quick Stats".
- **Pass if:** All three found.

## Test 3.3 — Today's session and summary referenced
- **Action:** Check for today's date (YYYY-MM-DD) in the file.
- **Expected:** Today's date appears in the log table.
- **Pass if:** Date found.

## Test 3.4 — Links point to existing files
- **Action:** Extract all markdown links `[...](...)` and verify targets exist.
- **Expected:** Every link target resolves to an existing file.
- **Pass if:** No broken links.
