# TDD Test: Templates

## Test 5.1 — Daily session template exists
- **Action:** Check `Templates/Daily_Session_Template.md`.
- **Expected:** File exists, non-empty.
- **Pass if:** File size > 200 bytes.

## Test 5.2 — Daily template has required placeholders
- **Action:** Read template.
- **Expected:** Contains `## Turn 001`, `### User Prompt`, `### Hermes Response`, ` ```text `, ` ```markdown `.
- **Pass if:** All placeholders found.

## Test 5.3 — Nightly summary template exists
- **Action:** Check `Templates/Nightly_Summary_Template.md`.
- **Expected:** File exists, non-empty.
- **Pass if:** File size > 200 bytes.

## Test 5.4 — Summary template has all required sections
- **Action:** Read summary template.
- **Expected:** Contains all: Executive Summary, Decisions Made, Key Learnings, Solutions/Fixes, Errors & Workarounds, Pending Tasks Identified, Files Created/Updated, Follow-up Recommendations.
- **Pass if:** All 8 sections found.
