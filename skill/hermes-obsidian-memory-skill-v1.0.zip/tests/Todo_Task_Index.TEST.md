# TDD Test: Todo Task Index

## Test 8.1 — Index file exists with __00_ prefix
- **Action:** Check `Todo_Tasks/__00_Todo_Task_Index.md` exists.
- **Expected:** File exists.
- **Pass if:** File exists.

## Test 8.2 — All referenced task files exist
- **Action:** Extract all `T##_*.md` links from index, verify each file exists.
- **Expected:** Every linked task file exists.
- **Pass if:** No broken links.

## Test 8.3 — Required columns present
- **Action:** Read file for column headers.
- **Expected:** Contains Title, Recorded, Status, Priority.
- **Pass if:** Columns found.
