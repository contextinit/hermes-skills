# TDD Test: Cross-File Linkage Consistency

## Test 9.1 — All session files have a corresponding summary placeholder
- **Action:** For every `Sessions/*_Session.md`, check `Summaries/*_Summary.md` exists.
- **Expected:** Every session has a summary.
- **Pass if:** Count matches.

## Test 9.2 — No orphan files
- **Action:** Check every file in Hermes_Memory/ is reachable from __00_Memory_Index.md or Hermes_Obsidian_Readme.md.
- **Expected:** All files are referenced.
- **Pass if:** At minimum, no file is truly unknown.

## Test 9.3 — Session file format matches template
- **Action:** Compare a session file's structure to Daily_Session_Template.md.
- **Expected:** Same headings (without requiring exact match).
- **Pass if:** Both have ## Turn, ### User Prompt, ### Hermes Response sections.
