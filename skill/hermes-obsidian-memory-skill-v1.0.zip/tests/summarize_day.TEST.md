# TDD Test: summarize_day.py

## Test 2.1 — Basic parse with --raw
- **Action:** `python3 ../Scripts/summarize_day.py --date today --raw`
- **Expected:** Valid JSON output with "date", "turns" array, "turn_count".
- **Pass if:** JSON parses, turn_count > 0.

## Test 2.2 — Turn extraction accuracy
- **Action:** Check that parsed turns contain expected strings from Test 1.x.
- **Expected:** At least one turn has "Test user prompt 1" in user_prompt.
- **Pass if:** Content is found.

## Test 2.3 — --date yesterday (no session)
- **Action:** `python3 ../Scripts/summarize_day.py --date yesterday --raw`
- **Expected:** Exits with 0, says "No session log found" or valid JSON for yesterday.
- **Pass if:** Graceful handling either way.

## Test 2.4 — Text mode output
- **Action:** `python3 ../Scripts/summarize_day.py --date today`
- **Expected:** Text output with "USER PROMPT:" and "RESPONSE:" sections.
- **Pass if:** Output contains both markers.

## Test 2.5 — Todo index fallback
- **Action:** Run text mode and check if it mentions the todo index.
- **Expected:** Output includes "Current Todo Tasks" or "(todo index not found)".
- **Pass if:** Todo section is present.
