# TDD Test: Plugin Hooks (__init__.py)

## Test 6.1 — Python syntax valid
- **Action:** `python3 -c "import ast; ast.parse(open('../Hooks/hermes-obsidian-memory-plugin/__init__.py').read()); print('OK')"`
- **Expected:** Prints "OK", no SyntaxError.
- **Pass if:** AST parses successfully.

## Test 6.2 — Key functions exist
- **Action:** Check file contains function/def names.
- **Expected:** Contains `register`, `on_session_start`, `on_session_end`, `pre_llm_call`, `post_llm_call`.
- **Pass if:** All 5 function names found.

## Test 6.3 — Environment variables documented
- **Action:** Check for HERMES_OBSIDIAN_MEMORY_DIR references.
- **Expected:** The env var is used as a path prefix.
- **Pass if:** Env var found.

## Test 6.4 — Append script path is correct
- **Action:** Check that APPEND_SCRIPT points to Scripts/append_turn.py.
- **Expected:** Path ends with `Hermes_Memory/Scripts/append_turn.py`.
- **Pass if:** Path is correct.
