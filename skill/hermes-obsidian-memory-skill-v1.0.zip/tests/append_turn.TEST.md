# TDD Test: append_turn.py

## Test 1.1 — Basic turn append
- **Action:** `python3 ../Scripts/append_turn.py --prompt "Test user prompt 1" --response "Test response 1"`
- **Expected:** Outputs "1". A file `Sessions/YYYY-MM-DD_Session.md` exists.
- **Pass if:** Output is a positive integer, file exists.

## Test 1.2 — Turn number auto-increment
- **Action:** Run append_turn.py again with different prompt/response.
- **Expected:** Outputs "2" (incremented).
- **Pass if:** Second call returns 2.

## Test 1.3 — Turn block format integrity
- **Action:** Read the session file and verify the turn blocks.
- **Expected:** Each turn has `## Turn NNN`, `### User Prompt — Verbatim`, `### Hermes Response / Actions`, ` ```text ` and ` ```markdown ` fences.
- **Pass if:** Both turns have complete structure.

## Test 1.4 — Special characters in prompt/response
- **Action:** `python3 ../Scripts/append_turn.py --prompt "Line1\nLine2 with $pecial & chars" --response "Code block with ``` backticks and \"quotes\""`
- **Expected:** Turn 3 appended without shell errors. All characters preserved in file.
- **Pass if:** Exit code 0, file content matches input exactly.

## Test 1.5 — Response with markdown formatting
- **Action:** `python3 ../Scripts/append_turn.py --prompt "Formatting test" --response "# Heading\n\n**Bold** and `code` and [link](https://example.com)"`
- **Expected:** Turn 4 appended. Markdown preserved inside ```markdown fence.
- **Pass if:** Content inside markdown fence is intact.
